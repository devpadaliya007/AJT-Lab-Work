<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page isErrorPage="true" %>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Exception Caught</title>
        <style>
        </style>
    </head>
    <body>
        <div class="error-message">
            <h2><strong>Exception Type:</strong> <%= exception.getClass().getName() %></h2>
            <p><% out.print(exception.getMessage()); %></p>
        </div>
    </body>
</html>