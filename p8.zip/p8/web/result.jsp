<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page errorPage="error.jsp" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Calculation Result</title>
    <style>
    </style>
</head>
<body>

    <%
        String num1Str = request.getParameter("num1");
        String num2Str = request.getParameter("num2");
        String op = request.getParameter("op");

        // Parsing inputs as integers to force ArithmeticException on zero division
        int a = Integer.parseInt(num1Str);
        int b = Integer.parseInt(num2Str);
        int result = 0;

        switch (op) {
            case "+":
                result = a + b;
                break;
            case "-":
                result = a - b;
                break;
            case "x":
                result = a * b;
                break;
            case "/":
                result = a / b;
                break;
        }
    %>

    <div class="result-box">
        <%= a %> <%= op %> <%= b %> = <strong><%= result %></strong>
    </div>

</body>
</html>
